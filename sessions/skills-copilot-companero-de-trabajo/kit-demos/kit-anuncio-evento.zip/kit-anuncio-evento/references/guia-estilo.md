# Guía de estilo de comunicación (ficticia, para demo)
- Tuteamos al público.
- Frases cortas; nada de jerga innecesaria.
- Un emoji como máximo por bloque y nunca en el asunto del correo.
- La llamada a la acción siempre al final: "Regístrate aquí: <enlace>".
- Nombramos a los ponentes con nombre y apellido la primera vez.
- Evitamos superlativos ("el mejor", "increíble").
